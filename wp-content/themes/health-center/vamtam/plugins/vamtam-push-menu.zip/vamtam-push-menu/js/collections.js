PM.Collections.Item =  Backbone.Collection.extend({
	model: PM.Models.Item
});

PM.Collections.Root =  Backbone.Collection.extend({
	model: PM.Models.Root
});